import React from "react";
import './home.css'
import Banner from '../../images/banner.jpg'
import { styled } from '@mui/material/styles';
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid';


function MainBlock() {
    const Item = styled(Paper)(({ theme }) => ({
        ...theme.typography.body2,
        padding: theme.spacing(1),
        textAlign: 'center',
        color: theme.palette.text.secondary,
    }));

    return (
        <div className='mainBlock'>
            <div className='mainBlockSecond'>

                <div className='mainBlockBanner'>
                    <img src={Banner} width='100%' alt="" />
                </div>
                <div>
                    <h1 className='restaurantHead'>
                        Restaurants List
                    </h1>
                    <div className='extradiv'></div>
                </div>

                <div className='listBlock'>
                    <Box>
                        <Grid className='mainGrid' container spacing={2}>
                            <Grid className='grid' item xs={12} md={8} lg={4} sm={6}>
                                <Item className='items'>
                                    <div style={{width:'100%',height:'100%',position:'absolute',top:'0',left:'0',backgroundColor:'rgba(196, 0, 59,0.8)',display:'flex',justifyContent:'center',alignItems:'center'}}>
                                        <h1 >Example</h1>
                                    </div>
                                    <img height='250px' width='auto' src={Banner} alt="" />
                                </Item>
                            </Grid>
                            <Grid className='grid' item xs={12} md={8} lg={4} sm={6}>
                                <Item className='items'>
                                    <div style={{width:'100%',height:'100%',position:'absolute',top:'0',left:'0',backgroundColor:'rgba(196, 0, 59,0.8)',display:'flex',justifyContent:'center',alignItems:'center'}}>
                                        <h1 >Example</h1>
                                    </div>
                                    <img height='250px' width='auto' src={Banner} alt="" />
                                </Item>
                            </Grid>
                            <Grid className='grid' item xs={12} md={8} lg={4} sm={6}>
                                <Item className='items'>
                                    <div style={{width:'100%',height:'100%',position:'absolute',top:'0',left:'0',backgroundColor:'rgba(196, 0, 59,0.8)',display:'flex',justifyContent:'center',alignItems:'center'}}>
                                        <h1 >Example</h1>
                                    </div>
                                    <img height='250px' width='auto' src={Banner} alt="" />
                                </Item>
                            </Grid>
                        </Grid>
                    </Box>
                </div>
            </div>

        </div>
    )
}
export default MainBlock
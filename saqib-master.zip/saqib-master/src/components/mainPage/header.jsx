import React from "react";
import './home.css'
import { AiFillHome } from 'react-icons/ai'
import { MdAccountCircle } from 'react-icons/md'

function Header() {
    return (
        <div className='header'>
            <div>
                <AiFillHome className='homeIocn' />
                <MdAccountCircle className='homeIocn' />
            </div>
        </div>
    )
}

export default Header
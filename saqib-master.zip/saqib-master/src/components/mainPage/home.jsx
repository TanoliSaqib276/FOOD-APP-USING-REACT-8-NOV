import React from "react";
import './home.css'
import Header from "./header";
import MainBlock from "./mainBlock";

function Home() {
    return(
        <div className='homeMain'>
            <Header />
            <MainBlock />
        </div>
    )
}

export default Home